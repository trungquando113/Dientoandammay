<?php
/**
 * GenMag Pro.
 *
 * This file adds the functions to the GenMag Pro Theme.
 *
 * @package GenMag Pro
 * @author  Vishal Jain
 * @license GPL-2.0+
 * @link    https://blogrouter.com
 */

// Start the engine
include_once( get_template_directory() . '/lib/init.php' );

// Child theme (do not remove)
define('CHILD_THEME_NAME', __('GenMag Pro', 'genmag-pro'));
define('CHILD_THEME_URL', 'https://blogrouter.com/');
define('CHILD_THEME_VERSION', '1.0');

// Add custom Viewport meta tag for mobile browsers
add_action('genesis_meta', 'gm_chrome_theme_meta_tag');

function gm_chrome_theme_meta_tag() {
    echo '<meta name="theme-color" content="#FF6200" />';
}

// Add HTML5 markup structure
add_theme_support('html5', array('search-form', 'comment-form', 'comment-list'));

// Add viewport meta tag for mobile browsers
add_theme_support('genesis-responsive-viewport');

// Add thee footer Widget
add_theme_support('genesis-footer-widgets', 3);

// Remove query string from static files
add_filter('style_loader_src', 'gm_remove_styles_scripts_query_string', 10, 2);
add_filter('script_loader_src', 'gm_remove_styles_scripts_query_string', 10, 2);
function gm_remove_styles_scripts_query_string($src) {
    if (strpos($src, '?ver='))
        $src = remove_query_arg('ver', $src);
    return $src;
}

// Enqueue Scripts
add_action('wp_enqueue_scripts', 'gm_genesis_enqueue_scripts');
function gm_genesis_enqueue_scripts() {
    wp_enqueue_script('genmag-pro-js', get_stylesheet_directory_uri() . '/lib/js/genmag-pro.js', array('jquery'), '1.0.0', true);
}

// Enqueue Styles
add_action('wp_enqueue_scripts', 'gm_genesis_enqueue_styles');
function gm_genesis_enqueue_styles() {
    //wp_enqueue_style('oxygen-font', '//fonts.googleapis.com/css?family=Oxygen:300,400,500,600,700', array());
    wp_enqueue_style('fa', get_stylesheet_directory_uri() . '/lib/css/font-awesome.min.css', array());
}

// Customize the Gravatar size in the author box
add_filter('genesis_author_box_gravatar_size', 'gm_author_box_gravatar_size');
function gm_author_box_gravatar_size($size) {
    return '100';
}

// Modify the size of the Gravatar in comments
add_filter('genesis_comment_list_args', 'gm_comments_gravatar_size');
function gm_comments_gravatar_size($args) {
    $args['avatar_size'] = 50;
    return $args;
}

// Customize Footer
remove_action('genesis_footer', 'genesis_do_footer');
add_action('genesis_footer', 'gm_custom_footer');
function gm_custom_footer() {
    ?>
    <p>&copy; Copyright 2017 <a href="<?php bloginfo('wpurl'); ?>"><?php bloginfo('name'); ?></a></p>
    <a href="#top" id="back-to-top"><i class="fa fa-chevron-up"></i></a>
    <?php
}

// Add Read More button for articles on Archive pages
add_filter('excerpt_more', 'gm_read_more_button');
function gm_read_more_button() {
   return '...&nbsp;<a class="read-more" href="' . get_permalink() . '">Read More »</a>';
}

// Code to Display Featured Image on top of the post
add_action('genesis_entry_content', 'gm_featured_post_image', 8);
function gm_featured_post_image($content) {
    if (!is_singular('post')) {
        return;
    }
    the_post_thumbnail('post-image');
    echo $content;
}

// Customize Entry Post Meta
add_filter('genesis_post_info', 'gm_post_info_filter');
function gm_post_info_filter($post_info) {
    if (!is_page()) {
        $post_info = '[post_author_posts_link before="<i class=\'fa fa-user\'></i> "] [post_categories before="<i class=\'fa fa-folder-open\'></i> "][post_date format="d/m/Y" before="<i class=\'fa fa-calendar\'></i> "]';
        return $post_info;
    }
}

// Remove Entry footer
remove_action('genesis_entry_footer', 'genesis_post_meta');

// Add custom thumbmails sizes
add_image_size('post-thumb', 640, 340, TRUE);
add_image_size('post-thumb', 300, 160, TRUE);
add_image_size('attachment-thumb', 100, 53, TRUE);

// Adding social media buttons settings
add_filter('genesis_theme_settings_defaults', 'gm_social_defaults');
function gm_social_defaults($defaults) {
    $list = gm_get_social_media_list();
    foreach ($list as $key => $val) {
        $defaults[$key . "_url"] = "";
    }
    return $defaults;
}

add_action('genesis_settings_sanitizer_init', 'gm_register_social_sanitization_filters');
function gm_register_social_sanitization_filters() {
    $settings_array = array();
    $list = gm_get_social_media_list();
    foreach ($list as $key => $val) {
        array_push($settings_array, $key . "_url");
    }
    genesis_add_option_filter('no_html', GENESIS_SETTINGS_FIELD, $settings_array);
}


add_action('genesis_theme_settings_metaboxes', 'gm_register_social_settings_box');
function gm_register_social_settings_box($_genesis_theme_settings_pagehook) {
    add_meta_box('br-social-settings', 'Social Icons (GenMag Pro)', 'gm_social_settings_box', $_genesis_theme_settings_pagehook, 'main', 'high');
}

function gm_social_settings_box() {
    ?>
    <table class="form-table">
        <tbody>
            <?php
            $list = gm_get_social_media_list();
            foreach ($list as $key => $val) {
                $url_slug = $key . "_url";
                ?>
                <tr>
                    <td><p><?php _e($val . ' URL', 'br-genesis-child'); ?></td>
                    <td><input class="regular-text" type="text" name="<?php echo GENESIS_SETTINGS_FIELD; ?>[<?php echo $url_slug; ?>]" value="<?php echo esc_url(genesis_get_option($url_slug)); ?>"/></td>
                </tr>
    <?php } ?>
        </tbody>
    </table>
    <?php
}

add_action('genesis_before_sidebar_widget_area', 'gm_display_social_icons_sidebar');
function gm_display_social_icons_sidebar() {
    ?>
    <section id="sidebar-social" class="widget">
        <div class="widget-wrap">
            <h4 class="widget-title">Follow Us</h4>
            <div id="social-icons">
                <ul>
                    <?php
                    $list = gm_get_social_media_list();
                    foreach ($list as $key => $val) {
                        $url_slug = $key . "_url";
                        ?>
                        <li>
                            <a href="<?php echo esc_url(genesis_get_option($url_slug)); ?>" rel="nofollow" target="_blank" class="<?php echo $key; ?>"></a>
                        </li>

    <?php } ?>
                </ul>
            </div>
        </div>
    </section>
    <?php
}

function gm_get_social_media_list() {
    $social_media['facebook'] = "Facebook";
    $social_media['twitter'] = "Twitter";
    $social_media['google-plus'] = "Google +";
    $social_media['youtube'] = "Youtube";
    $social_media['instagram'] = "Instagram";
    $social_media['reddit'] = "Reddit";
    $social_media['pinterest'] = "Pinterest";
    $social_media['email'] = "Email";
    $social_media['rss'] = "RSS Feed";
    return $social_media;
}
